import React, { useState } from 'react';
import { 
  SafeAreaView, View, Text, TextInput, ScrollView, 
  Image, StyleSheet, TouchableOpacity, ImageBackground, StatusBar
} from 'react-native';
import { Ionicons } from '@expo/vector-icons'; // Ikonkalar uchun

const initialPlaces = [
  { id: '1', title: 'Registon', price: '120,000', image: 'https://picsum.photos/id/1015/300/200', category: 'Tarix' },
  { id: '2', title: 'Buxoro', price: '110,000', image: 'https://picsum.photos/id/1018/300/200', category: 'Tarix' },
  { id: '3', title: 'Xiva', price: '150,000', image: 'https://picsum.photos/id/1043/300/200', category: 'Tarix' },
  { id: '4', title: 'Tog‘lar', price: '95,000', image: 'https://picsum.photos/id/1015/300/200', category: 'Tabiat' },
  { id: '5', title: 'Sohil', price: '200,000', image: 'https://picsum.photos/id/1018/300/200', category: 'Tabiat' },
];

export default function App() {
  const [showMain, setShowMain] = useState(false);
  const [search, setSearch] = useState('');

  const filtered = initialPlaces.filter(place =>
    place.title.toLowerCase().includes(search.toLowerCase())
  );

  // --- 1. PREMIUM KIRISH SAHIFASI ---
  if (!showMain) {
    return (
      <View style={styles.welcomeContainer}>
        <StatusBar barStyle="light-content" transparent />
        <ImageBackground 
          source={{ uri: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800' }} 
          style={styles.welcomeBg}
        >
          {/* Rasmni qorong'ulashtirish (Gradient effekti o'rniga) */}
          <View style={styles.welcomeOverlay}>
            
            <View style={styles.welcomeHeader}>
              <View style={styles.logoCircle}>
                <Ionicons name="airplane" size={40} color="#0d6efd" />
              </View>
              <Text style={styles.welcomeBrand}>UzTravel</Text>
            </View>

            <View style={styles.welcomeContent}>
              <Text style={styles.welcomeTagline}>Dunyoni biz bilan kashf eting</Text>
              <Text style={styles.welcomeDesc}>
                O'zbekistonning eng go'zal go'shalariga unutilmas sayohatlarni hoziroq rejalashtiring.
              </Text>
              
              <TouchableOpacity 
                style={styles.premiumButton} 
                onPress={() => setShowMain(true)}
                activeOpacity={0.8}
              >
                <Text style={styles.premiumButtonText}>Sayohatni boshlash</Text>
                <Ionicons name="chevron-forward" size={20} color="#fff" />
              </TouchableOpacity>
            </View>

          </View>
        </ImageBackground>
      </View>
    );
  }

  // --- 2. ASOSIY SAHIFА ---
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      <View style={styles.header}>
        <Text style={styles.headerText}>🌍 UzTravel</Text>
        <TouchableOpacity onPress={() => setShowMain(false)}>
           <Ionicons name="log-out-outline" size={24} color="#fff" />
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Ionicons name="search" size={20} color="#888" style={{marginRight: 10}} />
          <TextInput
            style={styles.searchInput}
            placeholder="Qayerga boramiz?"
            value={search}
            onChangeText={setSearch}
          />
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.sectionTitle}>Eng mashhur joylar</Text>
        {filtered.map(place => (
          <TouchableOpacity key={place.id} style={styles.card} onPress={() => alert(place.title)}>
            <Image source={{ uri: place.image }} style={styles.cardImage} />
            <View style={styles.cardInfo}>
              <View>
                <Text style={styles.cardTitle}>{place.title}</Text>
                <Text style={styles.cardCat}>{place.category}</Text>
              </View>
              <Text style={styles.cardPrice}>${place.price}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  // Kirish sahifasi styllari
  welcomeContainer: { flex: 1 },
  welcomeBg: { flex: 1 },
  welcomeOverlay: { 
    flex: 1, 
    backgroundColor: 'rgba(0,0,0,0.45)', 
    justifyContent: 'space-between', 
    padding: 30 
  },
  welcomeHeader: { alignItems: 'center', marginTop: 60 },
  logoCircle: { 
    backgroundColor: '#fff', 
    width: 80, height: 80, 
    borderRadius: 40, 
    justifyContent: 'center', 
    alignItems: 'center',
    elevation: 10
  },
  welcomeBrand: { color: '#fff', fontSize: 32, fontWeight: 'bold', marginTop: 15, letterSpacing: 2 },
  welcomeContent: { marginBottom: 40 },
  welcomeTagline: { color: '#fff', fontSize: 38, fontWeight: 'bold', lineHeight: 45, marginBottom: 15 },
  welcomeDesc: { color: '#ddd', fontSize: 16, lineHeight: 24, marginBottom: 30 },
  premiumButton: { 
    backgroundColor: '#0d6efd', 
    flexDirection: 'row',
    paddingVertical: 18, 
    borderRadius: 20, 
    alignItems: 'center', 
    justifyContent: 'center' 
  },
  premiumButtonText: { color: '#fff', fontSize: 18, fontWeight: 'bold', marginRight: 10 },

  // Asosiy sahifa styllari
  container: { flex: 1, backgroundColor: '#F8F9FA' },
  header: { 
    height: 100, backgroundColor: '#0d6efd', 
    flexDirection: 'row', justifyContent: 'space-between', 
    alignItems: 'center', paddingHorizontal: 20, paddingTop: 30 
  },
  headerText: { color: '#fff', fontSize: 24, fontWeight: 'bold' },
  searchContainer: { padding: 20 },
  searchBar: { 
    flexDirection: 'row', alignItems: 'center', 
    backgroundColor: '#fff', borderRadius: 15, 
    paddingHorizontal: 15, height: 55, elevation: 3 
  },
  searchInput: { flex: 1, fontSize: 16 },
  scrollContent: { paddingHorizontal: 20 },
  sectionTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 15, color: '#333' },
  card: { backgroundColor: '#fff', borderRadius: 20, marginBottom: 20, overflow: 'hidden', elevation: 5 },
  cardImage: { width: '100%', height: 180 },
  cardInfo: { padding: 15, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardTitle: { fontSize: 18, fontWeight: 'bold' },
  cardCat: { color: '#888' },
  cardPrice: { fontSize: 18, fontWeight: 'bold', color: '#0d6efd' }
});