<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Ma'lumotlar bazasi va til faylini ulash
include 'db.php'; 
include 'lang.php';
?>
<!DOCTYPE html>
<html lang="<?php echo $_SESSION['lang']; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UzTravel - <?php echo $L['sayohat'] . ' ' . $L['vaqti']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Banner dizayni */
        .hero-banner {
            height: 600px;
            background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), 
                        url('images/hero-bg.jpg');
            background-size: cover;
            background-position: center;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: white;
        }

        .text-sayohat {
            font-size: 50px;
            color: #f39c12; 
            text-transform: uppercase;
            font-weight: 900;
            display: block;
            letter-spacing: 5px;
            text-shadow: 3px 3px 10px rgba(0,0,0,0.5);
        }

        .text-vaqti-keldi {
            font-size: 90px;
            font-family: 'Brush Script MT', cursive; 
            color: #ffffff; 
            text-shadow: 4px 4px 15px rgba(0,0,0,0.6);
            display: block;
            margin-bottom: 30px;
        }

        .btn-band-qiling {
            background-color: #0652dd;
            color: white !important;
            padding: 15px 40px;
            border-radius: 50px;
            font-size: 20px;
            font-weight: bold;
            text-decoration: none;
            border: 3px solid white;
            transition: 0.4s;
        }

        .btn-band-qiling:hover {
            background-color: white;
            color: #0652dd !important;
            transform: translateY(-5px);
        }

        /* Navigatsiya */
        .top-bar { background-color: #34495e; color: white; padding: 8px 0; font-size: 14px; }
        .header-logo { padding: 20px 0; background-color: white; border-bottom: 3px solid #2ecc71; }
        .logo-text { font-size: 28px; font-weight: bold; color: #2980b9; text-decoration: none; }
        .logo-text span { color: #27ae60; }
        .main-nav { background-color: #2ecc71; position: sticky; top: 0; z-index: 1000; }
        .navbar-nav .nav-link { color: white !important; font-weight: 600; padding: 15px 20px !important; transition: 0.3s; }
        .navbar-nav .nav-link:hover { background-color: #27ae60; color: #f1c40f !important; }
        
        /* Card dizayni */
        .card-tour { border: none; border-radius: 20px; overflow: hidden; transition: 0.3s; box-shadow: 0 5px 15px rgba(0,0,0,0.08); }
        .card-tour:hover { transform: translateY(-10px); box-shadow: 0 15px 30px rgba(0,0,0,0.15); }
        .tour-img-container { height: 250px; overflow: hidden; background: #eee; }
        .tour-img-container img { width: 100%; height: 100%; object-fit: cover; }

        /* Stats Section */
        .stats-box h3 { font-size: 2.5rem; font-weight: 800; color: #2ecc71; }
    </style>
</head>
<body>

    <div class="top-bar">
        <div class="container d-flex justify-content-between align-items-center">
            <div>
                <a href="login.php" class="text-white text-decoration-none me-3"><i class="fa fa-user-lock"></i> Admin Login</a>
            </div>
            <div>
                <span><i class="fa fa-phone-alt"></i> +998 90 123-45-67</span>
                <span class="ms-4">
                    <a href="?lang=uz" class="text-white text-decoration-none fw-bold <?php echo ($_SESSION['lang'] == 'uz') ? 'text-warning' : ''; ?>">UZ</a> | 
                    <a href="?lang=ru" class="text-white text-decoration-none fw-bold <?php echo ($_SESSION['lang'] == 'ru') ? 'text-warning' : ''; ?>">RU</a> | 
                    <a href="?lang=en" class="text-white text-decoration-none fw-bold <?php echo ($_SESSION['lang'] == 'en') ? 'text-warning' : ''; ?>">EN</a>
                </span>
            </div>
        </div>
    </div>

    <div class="header-logo">
        <div class="container d-flex justify-content-between align-items-center flex-wrap">
            <a href="index.php" class="logo-text">Tourism <span>Management System</span></a>
            <div class="text-primary fw-bold d-none d-md-block"><i class="fa fa-check-circle"></i> SIFATLI VA ISHONCHLI XIZMAT</div>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg main-nav p-0">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav w-100 justify-content-center">
                    <li class="nav-item"><a class="nav-link" href="index.php"><?php echo $L['home']; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#about"><?php echo $L['about']; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#packages"><?php echo $L['tours']; ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="#contact"><?php echo $L['contact']; ?></a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="hero-banner">
        <div>
            <span class="text-sayohat"><?php echo $L['sayohat']; ?></span>
            <span class="text-vaqti-keldi"><?php echo $L['vaqti']; ?></span>
            <a href="#packages" class="btn-band-qiling shadow-lg"><?php echo $L['book']; ?></a>
        </div>
    </div>

    <section class="py-5 bg-white" id="about">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0">
                    <img src="https://images.unsplash.com/photo-1528127269322-539801943592?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" class="img-fluid rounded-4 shadow" alt="About">
                </div>
                <div class="col-lg-6 ps-lg-5">
                    <h6 class="text-primary fw-bold text-uppercase mb-2"><?php echo $L['about_title']; ?></h6>
                    <h2 class="fw-bold mb-4">UzTravel — Journey Beyond Your Dreams</h2>
                    <p class="text-muted mb-4 lead"><?php echo $L['about_text']; ?></p>
                    
                    <div class="row stats-box g-4">
                        <div class="col-sm-4">
                            <h3>10+</h3>
                            <small class="text-muted fw-bold"><?php echo $L['stats_exp']; ?></small>
                        </div>
                        <div class="col-sm-4">
                            <h3>5k+</h3>
                            <small class="text-muted fw-bold"><?php echo $L['stats_clients']; ?></small>
                        </div>
                        <div class="col-sm-4">
                            <h3>200+</h3>
                            <small class="text-muted fw-bold"><?php echo $L['stats_tours']; ?></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="container my-5" id="packages">
        <div class="text-center mb-5">
            <h2 class="fw-bold text-uppercase"><?php echo $L['tours']; ?></h2>
            <div style="height: 4px; width: 80px; background: #2ecc71; margin: 10px auto;"></div>
        </div>

        <div class="row g-4">
            <?php
            $res = $conn->query("SELECT * FROM tours GROUP BY title ORDER BY id ASC");
            if($res && $res->num_rows > 0):
                while($row = $res->fetch_assoc()): ?>
                <div class="col-lg-3 col-md-6"> 
                    <div class="card card-tour h-100">
                        <div class="tour-img-container">
                            <img src="images/<?php echo $row['image_url']; ?>" 
                                 onerror="this.src='https://via.placeholder.com/400x250?text=Rasm+topilmadi'" 
                                 alt="Tour">
                        </div>
                        <div class="card-body p-4 text-center">
                            <h5 class="fw-bold mb-3"><?php echo $row['title']; ?></h5>
                            <p class="text-muted small mb-4" style="height: 50px; overflow: hidden;">
                                <?php echo $row['description']; ?>
                            </p>
                            <h4 class="text-success fw-bold mb-3"><?php echo number_format($row['price'], 0, '.', ' '); ?> so'm</h4>
                            <a href="order.php?id=<?php echo $row['id']; ?>" class="btn btn-outline-primary rounded-pill w-100 fw-bold"><?php echo $L['bron']; ?></a>
                        </div>
                    </div>
                </div>
            <?php endwhile; 
            else: ?>
                <div class="col-12 text-center">
                    <div class="alert alert-warning">Hozircha tur paketlar mavjud emas.</div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="container my-5 py-5" id="contact">
        <div class="row">
            <div class="col-md-6 mx-auto card p-4 shadow-sm border-0" style="border-radius: 20px; background: #fff;">
                <h3 class="text-center fw-bold mb-4"><?php echo $L['contact']; ?></h3>
                <form action="send_message.php" method="POST">
                    <div class="mb-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Message</label>
                        <textarea name="message" class="form-control" rows="4" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-success w-100 fw-bold text-uppercase">Send Message</button>
                </form>
            </div>
        </div>
    </div>

    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p class="mb-0">&copy; 2026 Tourism Management System. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>