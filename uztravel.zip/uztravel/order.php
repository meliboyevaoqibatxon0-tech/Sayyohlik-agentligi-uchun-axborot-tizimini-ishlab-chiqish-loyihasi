<?php 
include 'db.php'; 

// Tanlangan turni bazadan olish
if(isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $tour_res = $conn->query("SELECT * FROM tours WHERE id=$id");
    $tour = $tour_res->fetch_assoc();
} else {
    header("Location: index.php");
    exit();
}

// Buyurtmani bazaga saqlash
if(isset($_POST['book_btn'])) {
    $name = mysqli_real_escape_string($conn, $_POST['client_name']);
    $phone = mysqli_real_escape_string($conn, $_POST['client_phone']);
    $tour_id = $id;

    $sql = "INSERT INTO orders (tour_id, client_name, client_phone) VALUES ('$tour_id', '$name', '$phone')";
    
    if($conn->query($sql)) {
        $msg = "Arizangiz muvaffaqiyatli yuborildi! Tez orada bog'lanamiz.";
    } else {
        $msg = "Xato yuz berdi, qaytadan urinib ko'ring.";
    }
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f1f2f6; }
        .order-card { 
            max-width: 600px; 
            margin: 50px auto; 
            border: none; 
            border-radius: 20px; 
            overflow: hidden; 
            box-shadow: 0 15px 35px rgba(0,0,0,0.1); 
        }
        .order-header { background: #0652dd; color: white; padding: 30px; text-align: center; }
        .btn-book { background: #27ae60; color: white; border-radius: 50px; padding: 12px; font-weight: bold; border: none; }
        .btn-book:hover { background: #2ecc71; color: white; }
    </style>
    <title>Sayohatni bron qilish</title>
</head>
<body>

<div class="container">
    <div class="card order-card">
        <div class="order-header">
            <h3>Sayohatni Band Qilish</h3>
            <p class="mb-0">Siz tanlagan yo'nalish: <b><?php echo $tour['title']; ?></b></p>
        </div>
        <div class="card-body p-4">
            <?php if(isset($msg)) echo "<div class='alert alert-success text-center'>$msg</div>"; ?>
            
            <form method="POST">
                <div class="mb-4">
                    <label class="form-label fw-bold">To'liq ismingiz</label>
                    <input type="text" name="client_name" class="form-control form-control-lg" placeholder="Masalan: Alisher Navoiy" required>
                </div>
                <div class="mb-4">
                    <label class="form-label fw-bold">Telefon raqamingiz</label>
                    <input type="text" name="client_phone" class="form-control form-control-lg" placeholder="+998 90 123 45 67" required>
                </div>
                <div class="alert alert-info small">
                    <i class="fa fa-info-circle me-2"></i> Narxi: <b><?php echo number_format($tour['price']); ?> so'm</b>
                </div>
                <button type="submit" name="book_btn" class="btn btn-book w-100 mt-3">TASDIQLASH VA YUBORISH</button>
                <a href="index.php" class="d-block text-center mt-3 text-muted text-decoration-none small">Asosiy sahifaga qaytish</a>
            </form>
        </div>
    </div>
</div>

</body>
</html>