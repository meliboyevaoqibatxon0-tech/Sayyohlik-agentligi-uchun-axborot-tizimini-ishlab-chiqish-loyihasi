<?php
session_start();

// Standart til - o'zbekcha
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'uz';
}

// Tilni o'zgartirish so'rovi kelgan bo'lsa
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

$languages = [
    'uz' => [
        'home' => 'BOSH SAHIFA',
        'about' => 'BIZ HAQIMIZDA',
        'tours' => 'TUR PAKETLAR',
        'contact' => 'ALOQA',
        'sayohat' => 'Sayohat',
        'vaqti' => 'Vaqti Keldi',
        'book' => 'HOZIROQ BAND QILING',
        'bron' => 'BRON QILISH',
        'phone' => 'Telefon raqami',
        'about_title' => 'Biz Haqimizda',
    'about_text' => 'Bizning agentligimiz O‘zbekiston bo‘ylab unutilmas sayohatlarni tashkil etishda 10 yillik tajribaga ega. Bizning maqsadimiz — har bir sayohatchiga yurtimizning boy madaniyati va go‘zalligini ko‘rsatishdir.',
    'stats_exp' => 'Yillik Tajriba',
    'stats_clients' => 'Mamnun Mijozlar',
    'stats_tours' => 'Muvaffaqiyatli Turlar',
    ],
    'ru' => [
        'home' => 'ГЛАВНАЯ',
        'about' => 'О НАС',
        'tours' => 'ТУР ПАКЕТЫ',
        'contact' => 'КОНТАКТЫ',
        'sayohat' => 'Время',
        'vaqti' => 'Путешествовать',
        'book' => 'ЗАБРОНИРОВАТЬ СЕЙЧАС',
        'bron' => 'ЗАБРОНИРОВАТЬ',
        'phone' => 'Номер телефона',
        'about_title' => 'О Нас',
    'about_text' => 'Наше агентство имеет 10-летний опыт организации незабываемых путешествий по Узбекистану. Наша цель — показать каждому путешественнику богатую культуру и красоту нашей страны.',
    'stats_exp' => 'Лет Опыта',
    'stats_clients' => 'Счастливых Клиентов',
    'stats_tours' => 'Успешных Туров',
    ],
    'en' => [
        'home' => 'HOME',
        'about' => 'ABOUT US',
        'tours' => 'TOUR PACKAGES',
        'contact' => 'CONTACT',
        'sayohat' => 'Time to',
        'vaqti' => 'Travel',
        'book' => 'BOOK NOW',
        'bron' => 'BOOKING',
        'phone' => 'Phone number',
        'about_title' => 'About Us',
    'about_text' => 'Our agency has 10 years of experience in organizing unforgettable trips across Uzbekistan. Our goal is to show every traveler the rich culture and beauty of our country.',
    'stats_exp' => 'Years Experience',
    'stats_clients' => 'Happy Clients',
    'stats_tours' => 'Successful Tours',
    ]
];

$L = $languages[$_SESSION['lang']];
?>