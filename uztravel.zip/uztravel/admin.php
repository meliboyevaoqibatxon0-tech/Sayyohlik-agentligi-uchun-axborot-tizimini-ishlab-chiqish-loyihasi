<?php
session_start();
if (!isset($_SESSION['admin_login'])) {
    header("Location: login.php");
    exit();
}
include 'db.php';

// 1. Yangi tur qo'shish mantiqi
if (isset($_POST['add_tour'])) {
    $title = $_POST['title'];
    $desc = $_POST['description'];
    $price = $_POST['price'];
    
    // Rasm yuklash
    $image_name = $_FILES['image']['name'];
    $target = "images/" . basename($image_name);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $sql = "INSERT INTO tours (title, description, price, image_url) VALUES ('$title', '$desc', '$price', '$image_name')";
        $conn->query($sql);
        echo "<script>alert('Yangi tur muvaffaqiyatli qo\'shildi!');</script>";
    }
}

// 2. Statistika
$total_orders = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'];
$total_messages = $conn->query("SELECT COUNT(*) as count FROM contacts")->fetch_assoc()['count'];
$total_tours = $conn->query("SELECT COUNT(*) as count FROM tours")->fetch_assoc()['count'];

// 3. Ma'lumotlarni olish
$result = $conn->query("SELECT orders.*, tours.title as tour_name FROM orders JOIN tours ON orders.tour_id = tours.id ORDER BY orders.id DESC");
$contact_result = $conn->query("SELECT * FROM contacts ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>UzTravel | Professional Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --sidebar-width: 260px; --primary: #1e293b; --accent: #3b82f6; }
        body { background: #f8fafc; font-family: 'Inter', sans-serif; }
        .sidebar { width: var(--sidebar-width); height: 100vh; position: fixed; background: var(--primary); color: white; }
        .main-content { margin-left: var(--sidebar-width); padding: 40px; }
        .nav-link { color: #94a3b8; padding: 12px 25px; transition: 0.3s; }
        .nav-link:hover, .nav-link.active { color: white; background: rgba(255,255,255,0.05); }
        .stat-card { border: none; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
        .table-card { background: white; border-radius: 12px; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); overflow: hidden; }
    </style>
</head>
<body>

    <div class="sidebar d-flex flex-column p-3">
        <h3 class="text-center mb-4 fw-bold text-info">UzTravel</h3>
        <hr>
        <nav class="nav flex-column">
            <a class="nav-link active" href="#"><i class="fa fa-chart-line me-2"></i> Dashboard</a>
            <a class="nav-link" href="#add_tour_sec"><i class="fa fa-plus-circle me-2"></i> Yangi Tur Qo'shish</a>
            <a class="nav-link" href="#orders_sec"><i class="fa fa-shopping-bag me-2"></i> Arizalar</a>
            <a class="nav-link" href="#msg_sec"><i class="fa fa-comment-alt me-2"></i> Xabarlar</a>
            <a class="nav-link text-warning" href="index.php"><i class="fa fa-arrow-left me-2"></i> Saytga Qaytish</a>
        </nav>
        <div class="mt-auto">
            <a href="logout.php" class="btn btn-outline-danger w-100">Chiqish</a>
        </div>
    </div>

    <div class="main-content">
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card stat-card p-3 bg-white border-start border-primary border-5">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><p class="text-muted mb-0">Jami Buyurtmalar</p><h2 class="fw-bold mb-0"><?= $total_orders ?></h2></div>
                        <i class="fa fa-shopping-cart fa-2x text-primary opacity-25"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card stat-card p-3 bg-white border-start border-success border-5">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><p class="text-muted mb-0">Mijozlar Fikri</p><h2 class="fw-bold mb-0"><?= $total_messages ?></h2></div>
                        <i class="fa fa-envelope fa-2x text-success opacity-25"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card stat-card p-3 bg-white border-start border-warning border-5">
                    <div class="d-flex justify-content-between align-items-center">
                        <div><p class="text-muted mb-0">Faol Turlar</p><h2 class="fw-bold mb-0"><?= $total_tours ?></h2></div>
                        <i class="fa fa-map-marked-alt fa-2x text-warning opacity-25"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="table-card p-4 mb-5" id="add_tour_sec">
            <h4 class="fw-bold mb-4"><i class="fa fa-plus me-2 text-primary"></i> Yangi Tur Paketi Qo'shish</h4>
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Tur Nomi</label>
                        <input type="text" name="title" class="form-control" placeholder="Masalan: Zamin Tog'lari" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Narxi (so'mda)</label>
                        <input type="number" name="price" class="form-control" placeholder="1000000" required>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Tavsif (Description)</label>
                        <textarea name="description" class="form-control" rows="3" required></textarea>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Rasm yuklash</label>
                        <input type="file" name="image" class="form-control" required>
                    </div>
                    <div class="col-md-6 d-flex align-items-end mb-3">
                        <button type="submit" name="add_tour" class="btn btn-primary w-100 fw-bold">TUR PAKETNI SAQLASH</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="table-card mb-5" id="orders_sec">
            <div class="bg-primary p-3 text-white"><h5 class="mb-0">Kelgan Arizalar</h5></div>
            <div class="p-3">
                <table class="table table-hover">
                    <thead><tr><th>ID</th><th>Mijoz</th><th>Telefon</th><th>Tanlangan Tur</th><th>Sana</th></tr></thead>
                    <tbody>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td>#<?= $row['id'] ?></td>
                            <td><strong><?= $row['client_name'] ?></strong></td>
                            <td><?= $row['client_phone'] ?></td>
                            <td><span class="badge bg-info text-dark"><?= $row['tour_name'] ?></span></td>
                            <td class="small"><?= $row['created_at'] ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>