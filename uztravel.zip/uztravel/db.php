<?php
// Ma'lumotlar bazasi parametrlari
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "travel_db";

// Ulanishni hosil qilish
$conn = new mysqli($host, $user, $pass, $dbname);

// UTF-8 kodirovkasini sozlash (O'zbekcha harflar xatosiz chiqishi uchun)
$conn->set_charset("utf8mb4");

// Ulanishni tekshirish
if ($conn->connect_error) {
    die("Bazaga ulanishda xato yuz berdi: " . $conn->connect_error);
}
?>