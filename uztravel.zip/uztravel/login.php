<?php
session_start();
if (isset($_POST['login_btn'])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    // BMI uchun sodda mantiq: login: admin, parol: 12345
    if ($user == 'admin' && $pass == '12345') {
        $_SESSION['admin_login'] = true;
        header("Location: admin.php");
    } else {
        $error = "Login yoki parol xato!";
    }
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Kirish - Admin Panel</title>
</head>
<body class="bg-secondary d-flex align-items-center" style="height: 100vh;">
    <div class="card mx-auto shadow-lg" style="width: 350px; border-radius: 15px;">
        <div class="card-body p-4 text-center">
            <h3 class="fw-bold mb-4">Admin Login</h3>
            <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
            <form method="POST">
                <input type="text" name="username" class="form-control mb-3" placeholder="Login" required>
                <input type="password" name="password" class="form-control mb-3" placeholder="Parol" required>
                <button name="login_btn" class="btn btn-primary w-100">KIRISH</button>
            </form>
            <a href="index.php" class="d-block mt-3 text-muted small">Saytga qaytish</a>
        </div>
    </div>
</body>
</html>