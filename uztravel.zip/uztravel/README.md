# UzTravel - Tourism Management System

Ushbu loyiha O'zbekiston bo'ylab sayohatlarni tashkil etish va boshqarish uchun yaratilgan veb-platformadir. Loyiha Bitiruv Malaka Ishi (BMI) doirasida ishlab chiqilgan.

## 🚀 Imkoniyatlar
* **Ko'p tilli interfeys:** Sayt 3 tilda (O'zbek, Rus, Ingliz) to'liq ishlaydi.
* **Dinamik Tur Paketlar:** Admin panel orqali yangi turlar qo'shish va rasmlar yuklash imkoniyati.
* **Bron qilish tizimi:** Mijozlar o'zlari tanlagan turga ariza qoldirishlari mumkin.
* **Aloqa tizimi:** Mijozlar savollari uchun qayta aloqa (Feedback) formasi.
* **Admin Dashboard:** Barcha arizalar va xabarlarni ko'rish hamda statistikani kuzatish uchun maxsus panel.

## 🛠 Texnologiyalar
* **Frontend:** HTML5, CSS3, Bootstrap 5, FontAwesome 6.
* **Backend:** PHP 8.x
* **Ma'lumotlar bazasi:** MySQL

## 📂 Loyiha Strukturasi
* `index.php` - Asosiy mijoz sahifasi.
* `admin.php` - Boshqaruv paneli (Faqat adminlar uchun).
* `db.php` - Ma'lumotlar bazasi bilan ulanish.
* `lang.php` - Ko'p tillilikni ta'minlovchi lug'at.
* `login.php` - Admin panelga kirish sahifasi.
* `images/` - Saytdagi barcha rasmlar saqlanadigan papka.

## ⚙️ O'rnatish qo'llanmasi
1. **XAMPP** yoki **OpenServer** dasturini ishga tushiring.
2. Papkani `C:/xampp/htdocs/uztravel` manziliga joylashtiring.
3. **phpMyAdmin** orqali `uztravel_db` nomli yangi baza oching.
4. Papka ichidagi `.sql` faylni ushbu bazaga **Import** qiling.
5. Brauzerda `localhost/uztravel` manzilini oching.

## 🔐 Admin Ma'lumotlari
* **Login:** `admin`
* **Parol:** `12345`

---
© 2026 UzTravel Project. Barcha huquqlar himoyalangan.